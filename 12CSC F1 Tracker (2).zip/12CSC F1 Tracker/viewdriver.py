
import wdc
import os
import matplotlib.pyplot as plt
import pandas as pd

def searchname(rows, driver_name):

    # Dictionary to store the total points for the driver
    driverdata = {}  

    # Dictionary to store the race results (track and position)
    raceresults = {}  
    
    for row in rows:
        if row["Driver"].lower() == driver_name.lower():
            driver = row["Driver"]
            points = row["Points"]
            track = row["Track"]
            driver_name = row["Driver"]
            
            # adding points for the driver
            if driver in driverdata:
                driverdata[driver] += points
            else:
                driverdata[driver] = points
            
            # Store the race result (track and position) for the driver
            raceresults[track] = row["Position"]
    
    # If no data is found for the driver, print an error message and return
    if not driverdata:
        print("No driver found [Enter in full name] e.g Lando Norris")
        return
    
    # Calculate total wins, points and identify the team for the driver
    wins = totalwins(rows, driver_name)
    pointsscored = driverdata[driver]
    team = teamidentify(rows, driver_name)
    
    # Calculate the driver’s rank in the championship standings
    wdc_leaderboard = wdc.pointcalc(rows)
    driver_rank = find_driver_rank(wdc_leaderboard, driver_name)
    
    # Display the results including driver performance and race placements
    displayresults(team, pointsscored, raceresults, wins, driver_name, driver_rank)

def teamidentify(rows, driver_name):
    team = None 
    for row in rows:
        if row["Driver"].lower() == driver_name.lower():
            team = row["Team"]
    
    return team

def totalwins(rows, driver_name):
    wins = 0  
    for row in rows:
        if row["Driver"].lower() == driver_name.lower():
            if row["Position"] == 1: 
             # The logic is if the driver’s position is 1, they’ve won the race
                wins += 1
    
    return wins

def find_driver_rank(wdc_leaderboard, driver_name):
    for position, (driver, _) in enumerate(wdc_leaderboard, start=1):
        # If the driver's name matches, return their rank
        if driver.lower() == driver_name.lower():
            return position
    # Return 'N/A' if the driver is not found
    return "N/A"  

def displayresults(team, pointsscored, raceresults, wins, driver_name, driver_rank):
    os.system('cls') 
    print(" "*19, f"🏎️  {driver_name}🏎️")
    print("-"*60)
    print(f"Championship rank: {driver_rank}")
    print(f"Total wins: {wins:< 10}")
    print(f"Points Scored: {pointsscored}")
    print(f"Team: {team}")
    print("-"*21,"Race placements","-"*22)
    # Displaying the race results
    for result in raceresults:
        print(f"{result}: {raceresults[result]}")
    
    print("-"*60)
    print("[Scroll up to view data]")
    
    # Ask the user if they want to view a performance graph
    decviewgraph = viewgraph()
    if decviewgraph == 1:
        # Plot the driver’s performance graph if user selects to view it
        plot_driver_performance(raceresults, driver_name)
        os.system('cls')
    else:
        os.system('cls') 
        pass

def viewgraph():
    while True:
        print("[1] View performance graph")
        print("[2] Continue")
        
        # Handle user input and ensure it’s valid
        while True:
            try:
                viewgraph = int(input("Enter your choice [1-2]: "))
                if 1 <= viewgraph <= 2:
                    return viewgraph
                else:
                    print("Please enter a number between 1 and 2.")
            except ValueError:
                print("That's not a valid number. Please enter a number between 1 and 2.")

def plot_driver_performance(raceresults, driver_name):
    if not raceresults:
        print(f"No race data available for {driver_name}.")
        return

    # Extract race names and positions from the raceresults dictionary
    races = list(raceresults.keys())
    positions = list(raceresults.values())

    # Create a new figure with a size of 10x5
    plt.figure(figsize=(10, 5))  

    # Plots the data for races vs. positions with a red solid line and circle markers
    plt.plot(races, positions, marker='o', linestyle='-', color='r', label="Finishing Position")  

    # Sets the label for the x-axis to "Races", indicating the x-axis represents race names/numbers
    plt.xlabel("Races")  

    # Sets the label for the y-axis to "Finishing Position", indicating the y-axis represents the finishing positions in the races
    plt.ylabel("Finishing Position")  

    # Sets the title of the plot using the driver's name dynamically
    plt.title(f"{driver_name}'s Performance in 2024 Season")  

    # Rotates the x-axis labels by 45 degrees and aligns them to the right for better readability
    plt.xticks(rotation=45, ha="right")  

    # Inverts the y-axis so that lower positions (better performance) are shown at the top of the plot
    plt.gca().invert_yaxis()  

    # Displays a legend on the plot using the label specified in the plt.plot() call
    plt.legend()  

    # Displays a grid on the plot to improve readability of data points
    plt.grid()  

    # Displays the plot window with the graph on the screen
    plt.show()  



