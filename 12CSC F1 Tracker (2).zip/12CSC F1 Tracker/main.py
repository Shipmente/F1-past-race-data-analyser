import csvreader  
import choice     
import os         

def main():
    # Clear the console screen
    os.system('cls')

    # Define the file path to the race results CSV
    file_path = r"C:\Users\ryanc\Desktop\12CSC F1 Tracker\Formula1_2024season_raceResults.csv"

    # Read the CSV file and store its data in 'rows'
    rows = csvreader.read_csv(file_path)

    # Validate the data to ensure integrity before processing
    csvreader.validate_data(rows)
    
    while True:  
        # Get the user's selected menu option
        choice_picked = choice.choices()
        if not choice.selection(choice_picked, rows): 
            break  

# the start of the program
main()
