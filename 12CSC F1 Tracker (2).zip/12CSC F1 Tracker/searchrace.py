import os

# finding the driver who set the fastest lap in a specific race
def find_fastest_lap(rows, track_name):
    for row in rows:
        if row['Track'].lower() == track_name.lower() and row['Set Fastest Lap'].strip().lower() == 'yes':

            # Return the driver and their fastest lap time if found
            return {'Driver': row['Driver'], 'Fastest Lap Time': row['Fastest Lap Time']}
    return None  


def sort_key(x): 
    # If 'Position' has a value, return it for sorting.
    # If 'Position' is None (NC/DQ), place it at the end by returning a very large number.
    return x['Position'] if x['Position'] is not None else float('inf')
                                                                 
# Function to print the race results for a specific track
def print_race_results(rows, track_name):
    os.system('cls')  
    
    # List to hold race results for the track
    race_results = []    
    for row in rows:
        if row['Track'].lower() == track_name.lower():
            race_results.append(row)
    if not race_results:
        print(f"❌ No race found for '{track_name}'. Please check the spelling and try again.")
        return
    
    print(f"🏁 {track_name} Grand Prix Results 🏁")
    print("-" * 60)
    print(f"{'Pos':<5} {'Driver':<20} {'Team':<30} {'Points':<6}")
    print("-" * 60)

    # Sort the race results by position
    race_results.sort(key=sort_key)

    # Loop through and print each race result
    for row in race_results:
        pos_display = row['Position'] if row['Position'] is not None else "NC/DQ"
        print(f"{pos_display:<5} {row['Driver']:<20} {row['Team']:<30} {row['Points']:<6}")

    # Find and display the driver with the fastest lap
    fastest_lap = find_fastest_lap(rows, track_name)
    if fastest_lap:
        print(f"🏎️ Fastest Lap: {fastest_lap['Driver']} - {fastest_lap['Fastest Lap Time']}")

    print("-" * 60)
