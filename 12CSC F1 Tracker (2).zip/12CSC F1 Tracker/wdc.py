import os
def get_points(driver_data):
    # team data is represented as a tuple, setting [1] finds the second element of the tuple in teampoints which is points, the one we are looking for.
    return driver_data[1]

def pointcalc(rows):
    os.system('cls')
    driverpoints = {}
    for row in rows:
        driver = row["Driver"]
        points = row["Points"]
        if driver in driverpoints:
            driverpoints[driver ]+= points
        else:
            driverpoints[driver] = points
    #sorted stores items into wdclead as a list of tuples in descending order based on the points defined by the key in descending order by reverse
    wdc_leaderboard = sorted(driverpoints.items(), key=get_points, reverse=True)
    return wdc_leaderboard

def printleaderboard(wdc_leaderboard):
    print("\n🏆 2024 World Drivers' Championship Standings 🏆")
    print("-" * 50)
    print(f"{'Pos':<5} {'Driver':<25} {'Total Points':<10}")
    print("-" * 50)
    
    #Starts the leaderboard counting from 1 instead of 0 as computers start at 0 which is unideal for the tracker.
    for position, (driver, points) in enumerate(wdc_leaderboard, start=1):
        print(f"{position:<5} {driver:<25} {points:<10}")
    print("-" * 50)


