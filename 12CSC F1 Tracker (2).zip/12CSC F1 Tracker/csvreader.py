import csv 

# Validate and convert data in the rows
def validate_data(rows):
    for row in rows:
        try:
            # If the position is NC or DQ set it to None, else convert to integer
            if row['Position'] in ['NC', 'DQ']:
                row['Position'] = None  
            else:
                row['Position'] = int(row['Position'])  

            # Convert Starting Grid, Laps and Points to integers
            row['Starting Grid'] = int(row['Starting Grid'])
            row['Laps'] = int(row['Laps'])
            row['Points'] = int(row['Points'])

        except ValueError:
            # Raise an error if invalid data is found in the row
            raise ValueError(f"Invalid data found: {row}")


def read_csv(file_path):
    # Open the CSV file in read mode with UTF-8 encoding
    with open(file_path, newline='', encoding='utf-8') as file:
        # Use the csv.DictReader to read the rows as dictionaries
        reader = csv.DictReader(file)
        # Convert the reader object to a list of rows (dictionaries)
        rows = list(reader) 
    return rows  






