import os
def getpoints(teamdata):
    # team data is represented as a tuple, setting [1] finds the second element of the tuple in teampoints which is points, the one we are looking for.
    return teamdata[1]

def teampointcalc(rows):
    os.system('cls')
    teampoints = {}
    for row in rows:
        team = row["Team"]
        points = row["Points"]
        if team in teampoints:
            teampoints[team] += points
        else:
            teampoints [team] = points
    #sorted stores items into wcclead as a list of tuples in descending order based on the points defined by the key in descending order by reverse
    wccleaderboard = sorted(teampoints.items(), key=getpoints, reverse=True)
    printleaderboard(wccleaderboard)

def printleaderboard(wccleaderboard):
    print("\n🏆 2024 World Constructors' Championship Standings 🏆")
    print("-" * 50)
    print(f"{'Pos':<5} {'Team':<40} {'Total Points':<10}")
    print("-" * 50)
    #Starts the leaderboard counting from 1 instead of 0 as computers start at 0 which is unideal for the tracker.
    for position, (team, points) in enumerate(wccleaderboard, start=1): 
        print(f"{position:<5} {team:<40} {points:<10}")
    print("-" * 50)