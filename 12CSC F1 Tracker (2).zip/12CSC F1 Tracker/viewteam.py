import os
def searchteam(rows, team_name):
    # Dictionary to hold the total points for the team
    teamdata = {}  
    
    # Loop through each row in the data
    for row in rows:
        # finds if the team name matches
        if row["Team"].lower() == team_name.lower():
            team = row["Team"]
            points = row["Points"]
            team_name = row["Team"]
            
            # If the team already exists in teamdata, add the points, else add the team with initial points
            if team in teamdata:
                teamdata[team] += points
            else:
                teamdata[team] = points
    
    # If no team is found, print a message and return
    if not teamdata:
        print("No team found [Enter in full name] e.g 'Mclaren Mercedes'")
        return
    
    # Get total wins, points scored, and drivers for the team
    wins = totalwins(rows, team_name)
    pointsscored = teamdata[team]
    drivers = driversidentify(rows, team_name)
    
    # Display the results of the team's performance
    displayresults(pointsscored, wins, team_name, drivers)

def driversidentify(rows, team_name):
    # List to hold unique drivers
    drivers = []  

    # Dictionary to store team drivers
    teamdrivers = {}  
    
    for row in rows:
        # If the  theirteam matches, add the driver to the list if not already added
        if row["Team"].lower() == team_name.lower():
            driveriden = row["Driver"]
            if driveriden not in drivers:
                drivers.append(driveriden)
    
    # Add the list of drivers to the dictionary under the key "Drivers"
    teamdrivers["Drivers"] = drivers
    return teamdrivers

def totalwins(rows, team_name):
    wins = 0 
    
    for row in rows:
        # If the team matches and the position is 1 (win), add 1 to the wins counter
        if row["Team"].lower() == team_name.lower():
            if row["Position"] == 1:
                wins += 1
    
    return wins 

def displayresults(pointsscored, wins, team_name, drivers):
    os.system('cls') 
    # The - will create a readable and aesthetically nice looking output of the team data
    print(" "*19, f"🏎️  {team_name}🏎️")
    print("-"*60)
    print(f"Total wins: {wins:< 10}")
    print(f"Points Scored: {pointsscored}")
    print("-"*60)
    
    print("Drivers:")
    for driver in drivers.get("Drivers", []):
        print(driver)
    
    print("-"*60)

