import csvreader
import searchrace
import wdc
import wcc
import viewdriver
import viewteam
import os

def choices():
    print("-"*60)
    print("Welcome to the formula one championship and performance tracker!")
    print("-"*60)
    print("[1] View Driver's championship leaderboard")
    print("[2] View Constructor's championship leaderboard")
    print("[3] View race results")
    print("[4] Search for Driver performance")
    print("[5] Search for Team performance")
    print("[6] Exit")
    
    while True:
        try:
            # Accepting and validating user input for menu options
            choice = int(input("Enter your choice [1-6]: "))
            # Ensuring the input is within the valid range
            if 1 <= choice <= 6:
                return choice
            else:
                # Error message for invalid range
                print("Please enter a number between 1 and 6.") 
        except ValueError:
            # Error for non-integer input
            print("That's not a valid number. Please enter a number between 1 and 6.")  

def selection(choice, rows):
    if choice == 1:
        # Display the Driver's Championship leaderboard
        while True:
            # Calculate and get the leaderboard data
            wdcleaderboard = wdc.pointcalc(rows) 

            # Print the leaderboard
            wdc.printleaderboard(wdcleaderboard) 
            print("Scroll up to read.")
            contin = input("Press [ENTER] to continue: ") 
            if contin.lower() == "":  
                os.system('cls')  
                return True 

    elif choice == 2:
        # Display the Constructor's Championship leaderboard
        while True:
            # Calculate the constructor leaderboard
            wcc.teampointcalc(rows)  
            print("Scroll up to read.")
            contin = input("Press [ENTER] to continue: ") 
            if contin.lower() == "":  
                os.system('cls')  
                return True 

    elif choice == 3:
        # View results of a specific race
        while True:
            track_name = input("🔎 Enter a race name (or type 'exit' to quit): ")
            if track_name.lower() == "exit":  
                print("Returning to main menu... 🏎️💨")
                os.system('cls') 
                return True 
            else:
                # Search and display the race results for the searched track name
                searchrace.print_race_results(rows, track_name)

    elif choice == 4:
        # Search for a specific driver's performance
        while True:
            driver_name = input("Enter driver name (or type 'exit' to quit): ")  
            if driver_name.lower() == "exit":  
                print("Returning to main menu...")
                os.system('cls') 
                return True  
            else:
                # Search and display the performance data for the driver
                viewdriver.searchname(rows, driver_name)

    elif choice == 5:
        # Search for a specific team's performance
        while True:
            team_name = input("Enter team name (or type 'EXIT'): ")  
            if team_name.lower() == "exit":  
                print("Returning to main menu...")
                os.system('cls') 
                return True 
            else:
                # Search and display the performance data for the team
                viewteam.searchteam(rows, team_name)

    elif choice == 6:
        # Exit the program
        print("Goodbye! 🏎️💨")
        return False 

    else:
        # In case of an invalid choice, return True to stay in the menu
        return True
